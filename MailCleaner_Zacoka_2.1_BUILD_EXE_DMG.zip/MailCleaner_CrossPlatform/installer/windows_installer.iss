
#define MyAppName "MailCleaner Zacoka"
#define MyAppVersion "2.1"
#define MyAppPublisher "Zacoka"
#define MyAppExeName "MailCleaner Zacoka.exe"

[Setup]
AppId={{D3D56D25-18A1-4B12-A9E0-0CCF1820AC78}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\MailCleaner Zacoka
DefaultGroupName=MailCleaner Zacoka
OutputDir=..\release
OutputBaseFilename=MailCleaner_Zacoka_Setup_Windows
Compression=lzma
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "..\dist\MailCleaner Zacoka\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\MailCleaner Zacoka"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\MailCleaner Zacoka"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Créer un raccourci sur le Bureau"; GroupDescription: "Raccourcis :"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Lancer MailCleaner Zacoka"; Flags: nowait postinstall skipifsilent
