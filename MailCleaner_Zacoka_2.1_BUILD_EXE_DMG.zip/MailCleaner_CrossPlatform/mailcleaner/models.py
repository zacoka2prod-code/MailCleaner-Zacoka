
from dataclasses import dataclass
from datetime import datetime

@dataclass
class MailItem:
    provider: str
    account_id: str
    message_id: str
    date: datetime | None
    sender: str
    subject: str
    size_bytes: int
    unread: bool
    newsletter: bool
    has_attachment: bool
    folder: str = "Inbox"

    @property
    def size_text(self) -> str:
        size = float(self.size_bytes)
        units = ["o", "Ko", "Mo", "Go"]
        for unit in units:
            if size < 1024 or unit == units[-1]:
                return f"{size:.1f} {unit}" if unit != "o" else f"{int(size)} {unit}"
            size /= 1024
        return f"{int(self.size_bytes)} o"
