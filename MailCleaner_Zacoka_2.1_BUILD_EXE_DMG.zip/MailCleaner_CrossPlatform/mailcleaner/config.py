
import json
from pathlib import Path
from platformdirs import user_config_dir, user_data_dir

APP_NAME = "MailCleaner Zacoka"
CONFIG_DIR = Path(user_config_dir(APP_NAME))
DATA_DIR = Path(user_data_dir(APP_NAME))
CONFIG_FILE = CONFIG_DIR / "config.json"
GOOGLE_CREDENTIALS = CONFIG_DIR / "google_credentials.json"
GOOGLE_TOKEN = DATA_DIR / "google_token.json"
MS_TOKEN_CACHE = DATA_DIR / "microsoft_token_cache.bin"

DEFAULT_CONFIG = {
    "microsoft_client_id": "",
    "ovh_accounts": [],
    "safe_mode": True,
}

def ensure_dirs():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

def load_config():
    ensure_dirs()
    if not CONFIG_FILE.exists():
        return DEFAULT_CONFIG.copy()
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        merged = DEFAULT_CONFIG.copy()
        merged.update(data)
        return merged
    except Exception:
        return DEFAULT_CONFIG.copy()

def save_config(config):
    ensure_dirs()
    CONFIG_FILE.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
