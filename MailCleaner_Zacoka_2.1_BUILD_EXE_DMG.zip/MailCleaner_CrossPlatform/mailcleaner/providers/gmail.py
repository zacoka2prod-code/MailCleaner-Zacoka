
import base64
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

from .base import MailProvider
from ..models import MailItem
from ..config import GOOGLE_CREDENTIALS, GOOGLE_TOKEN, ensure_dirs

SCOPES = ["https://www.googleapis.com/auth/gmail.modify"]

class GmailProvider(MailProvider):
    def __init__(self):
        self.service = None
        self.email = ""

    def connect(self):
        ensure_dirs()
        if not GOOGLE_CREDENTIALS.exists():
            raise RuntimeError(
                "Le fichier OAuth Google n'est pas configuré. "
                "Ouvrez Paramètres > Google OAuth et sélectionnez le fichier JSON téléchargé."
            )
        creds = None
        if GOOGLE_TOKEN.exists():
            try:
                creds = Credentials.from_authorized_user_file(str(GOOGLE_TOKEN), SCOPES)
            except Exception:
                creds = None
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(str(GOOGLE_CREDENTIALS), SCOPES)
                creds = flow.run_local_server(
                    host="localhost",
                    port=0,
                    open_browser=True,
                    prompt="consent",
                    authorization_prompt_message=(
                        "Le navigateur va s'ouvrir. Si rien ne s'ouvre, copiez cette adresse : {url}"
                    ),
                    success_message=(
                        "Connexion Google réussie. Vous pouvez fermer cette page et revenir dans MailCleaner."
                    ),
                )
            GOOGLE_TOKEN.write_text(creds.to_json(), encoding="utf-8")
        self.service = build("gmail", "v1", credentials=creds, cache_discovery=False)
        profile = self.service.users().getProfile(userId="me").execute()
        self.email = profile.get("emailAddress", "Gmail")
        return self.email

    def account_label(self):
        return self.email or "Gmail"

    @staticmethod
    def _headers(payload):
        return {
            h.get("name", "").lower(): h.get("value", "")
            for h in payload.get("headers", [])
        }

    def scan(self, rules, progress=None):
        if not self.service:
            self.connect()
        query = ["in:inbox"]
        if rules.get("older_days"):
            query.append(f"older_than:{int(rules['older_days'])}d")
        if rules.get("larger_mb"):
            query.append(f"larger:{int(rules['larger_mb'])}M")
        if rules.get("unread_only"):
            query.append("is:unread")
        if rules.get("sender"):
            query.append(f"from:({rules['sender']})")
        if rules.get("subject"):
            query.append(f"subject:({rules['subject']})")
        if rules.get("has_attachment"):
            query.append("has:attachment")

        max_items = int(rules.get("limit", 500))
        ids = []
        token = None
        while len(ids) < max_items:
            result = self.service.users().messages().list(
                userId="me", q=" ".join(query), maxResults=min(500, max_items-len(ids)),
                pageToken=token
            ).execute()
            ids.extend(result.get("messages", []))
            token = result.get("nextPageToken")
            if not token:
                break

        output = []
        for index, row in enumerate(ids[:max_items], 1):
            msg = self.service.users().messages().get(
                userId="me", id=row["id"], format="metadata",
                metadataHeaders=["From", "Subject", "Date", "List-Unsubscribe", "List-Id", "Precedence"]
            ).execute()
            headers = self._headers(msg.get("payload", {}))
            labels = set(msg.get("labelIds", []))
            dt = None
            try:
                dt = parsedate_to_datetime(headers.get("date", ""))
                if dt and dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
            except Exception:
                pass
            newsletter = any(headers.get(k) for k in ("list-unsubscribe", "list-id", "precedence"))
            if rules.get("newsletter_only") and not newsletter:
                continue
            payload = msg.get("payload", {})
            has_attachment = self._has_attachment(payload)
            item = MailItem(
                provider="Gmail", account_id=self.email, message_id=msg["id"],
                date=dt, sender=headers.get("from", ""), subject=headers.get("subject", ""),
                size_bytes=int(msg.get("sizeEstimate", 0)), unread="UNREAD" in labels,
                newsletter=newsletter, has_attachment=has_attachment
            )
            output.append(item)
            if progress:
                progress(index, len(ids), len(output))
        return output

    def _has_attachment(self, payload):
        if payload.get("filename"):
            return True
        return any(self._has_attachment(part) for part in payload.get("parts", []))

    def archive(self, message_ids):
        for mid in message_ids:
            self.service.users().messages().modify(
                userId="me", id=mid, body={"removeLabelIds": ["INBOX"]}
            ).execute()

    def trash(self, message_ids):
        for mid in message_ids:
            self.service.users().messages().trash(userId="me", id=mid).execute()
