
import json
from datetime import datetime
import requests
import msal

from .base import MailProvider
from ..models import MailItem
from ..config import MS_TOKEN_CACHE, ensure_dirs

GRAPH = "https://graph.microsoft.com/v1.0"
SCOPES = ["User.Read", "Mail.ReadWrite"]

class MicrosoftProvider(MailProvider):
    def __init__(self, client_id):
        self.client_id = client_id.strip()
        self.email = ""
        self.access_token = ""
        self.cache = msal.SerializableTokenCache()

    def connect(self):
        if not self.client_id:
            raise RuntimeError(
                "L'identifiant d'application Microsoft n'est pas configuré. "
                "Ouvrez Paramètres > Microsoft OAuth."
            )
        ensure_dirs()
        if MS_TOKEN_CACHE.exists():
            try:
                self.cache.deserialize(MS_TOKEN_CACHE.read_text(encoding="utf-8"))
            except Exception:
                pass
        app = msal.PublicClientApplication(
            self.client_id,
            authority="https://login.microsoftonline.com/common",
            token_cache=self.cache,
        )
        accounts = app.get_accounts()
        result = app.acquire_token_silent(SCOPES, account=accounts[0]) if accounts else None
        if not result:
            result = app.acquire_token_interactive(
                scopes=SCOPES,
                prompt="select_account",
                success_template=(
                    "<html><body style='font-family:Arial;text-align:center;padding:50px'>"
                    "<h2>Connexion réussie</h2>"
                    "<p>Vous pouvez fermer cette fenêtre et revenir dans MailCleaner.</p>"
                    "</body></html>"
                ),
                error_template=(
                    "<html><body style='font-family:Arial;text-align:center;padding:50px'>"
                    "<h2>Connexion impossible</h2>"
                    "<p>Revenez dans MailCleaner pour voir le détail.</p>"
                    "</body></html>"
                ),
            )
        if "access_token" not in result:
            raise RuntimeError(result.get("error_description", "Connexion Microsoft annulée ou refusée."))
        self.access_token = result["access_token"]
        if self.cache.has_state_changed:
            MS_TOKEN_CACHE.write_text(self.cache.serialize(), encoding="utf-8")
        me = self._request("GET", "/me")
        self.email = me.get("mail") or me.get("userPrincipalName") or "Microsoft"
        return self.email

    def account_label(self):
        return self.email or "Microsoft"

    def _request(self, method, path, **kwargs):
        headers = kwargs.pop("headers", {})
        headers["Authorization"] = f"Bearer {self.access_token}"
        headers.setdefault("Accept", "application/json")
        response = requests.request(method, GRAPH + path, headers=headers, timeout=60, **kwargs)
        if response.status_code >= 400:
            raise RuntimeError(f"Microsoft Graph {response.status_code}: {response.text[:500]}")
        return response.json() if response.content else {}

    def scan(self, rules, progress=None):
        if not self.access_token:
            self.connect()
        limit = min(int(rules.get("limit", 500)), 2000)
        select = "id,subject,from,receivedDateTime,isRead,hasAttachments,bodyPreview"
        url = f"/me/mailFolders/inbox/messages?$top={min(limit,100)}&$select={select}&$orderby=receivedDateTime desc"
        items = []
        checked = 0
        while url and checked < limit:
            data = self._request("GET", url if url.startswith("/") else url.replace(GRAPH, ""))
            for msg in data.get("value", []):
                checked += 1
                sender = (((msg.get("from") or {}).get("emailAddress") or {}).get("address") or "")
                subject = msg.get("subject") or ""
                received = msg.get("receivedDateTime")
                dt = datetime.fromisoformat(received.replace("Z", "+00:00")) if received else None
                newsletter = any(token in (msg.get("bodyPreview") or "").lower()
                                 for token in ("unsubscribe", "désabonner", "se désinscrire"))
                if not self._matches(msg, sender, subject, dt, newsletter, rules):
                    continue
                items.append(MailItem(
                    provider="Microsoft", account_id=self.email, message_id=msg["id"], date=dt,
                    sender=sender, subject=subject, size_bytes=0,
                    unread=not bool(msg.get("isRead")), newsletter=newsletter,
                    has_attachment=bool(msg.get("hasAttachments"))
                ))
                if progress:
                    progress(checked, limit, len(items))
                if checked >= limit:
                    break
            next_link = data.get("@odata.nextLink")
            url = next_link
        return items

    def _matches(self, msg, sender, subject, dt, newsletter, rules):
        from datetime import datetime, timezone, timedelta
        if rules.get("unread_only") and msg.get("isRead"):
            return False
        if rules.get("has_attachment") and not msg.get("hasAttachments"):
            return False
        if rules.get("newsletter_only") and not newsletter:
            return False
        if rules.get("sender") and rules["sender"].lower() not in sender.lower():
            return False
        if rules.get("subject") and rules["subject"].lower() not in subject.lower():
            return False
        if rules.get("older_days") and dt:
            if dt >= datetime.now(timezone.utc) - timedelta(days=int(rules["older_days"])):
                return False
        return True

    def archive(self, message_ids):
        archive = self._request("GET", "/me/mailFolders/archive?$select=id")
        folder_id = archive["id"]
        for mid in message_ids:
            self._request("POST", f"/me/messages/{mid}/move", json={"destinationId": folder_id})

    def trash(self, message_ids):
        deleted = self._request("GET", "/me/mailFolders/deleteditems?$select=id")
        folder_id = deleted["id"]
        for mid in message_ids:
            self._request("POST", f"/me/messages/{mid}/move", json={"destinationId": folder_id})
