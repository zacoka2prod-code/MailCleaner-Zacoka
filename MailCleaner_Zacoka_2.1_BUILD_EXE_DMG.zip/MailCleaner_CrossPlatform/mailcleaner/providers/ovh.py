
import email
import imaplib
import re
import ssl
from datetime import datetime, timezone, timedelta
from email.header import decode_header, make_header
from email.utils import parsedate_to_datetime

import keyring

from .base import MailProvider
from ..models import MailItem

SERVICE = "MailCleaner Zacoka OVH"

def decode(value):
    if not value:
        return ""
    try:
        return str(make_header(decode_header(value)))
    except Exception:
        return value

class OvhProvider(MailProvider):
    def __init__(self, address, host="ssl0.ovh.net", port=993):
        self.address = address
        self.host = host
        self.port = int(port)
        self.client = None

    def set_password(self, password):
        keyring.set_password(SERVICE, self.address, password)

    def connect(self):
        password = keyring.get_password(SERVICE, self.address)
        if not password:
            raise RuntimeError("Aucun mot de passe OVH enregistré pour cette boîte.")
        self.client = imaplib.IMAP4_SSL(self.host, self.port, ssl_context=ssl.create_default_context())
        self.client.login(self.address, password)
        return self.address

    def account_label(self):
        return self.address

    def scan(self, rules, progress=None):
        if not self.client:
            self.connect()
        self.client.select("INBOX", readonly=True)
        status, data = self.client.uid("search", None, "UNSEEN" if rules.get("unread_only") else "ALL")
        if status != "OK":
            raise RuntimeError("Recherche IMAP OVH impossible.")
        ids = data[0].split()[-int(rules.get("limit", 500)):]
        output = []
        cutoff = datetime.now(timezone.utc) - timedelta(days=int(rules.get("older_days", 0))) if rules.get("older_days") else None
        for i, uid_b in enumerate(reversed(ids), 1):
            uid = uid_b.decode()
            status, parts = self.client.uid(
                "fetch", uid,
                "(BODY.PEEK[HEADER.FIELDS (DATE FROM SUBJECT LIST-UNSUBSCRIBE LIST-ID PRECEDENCE CONTENT-DISPOSITION)] RFC822.SIZE FLAGS)"
            )
            if status != "OK":
                continue
            raw = b""
            meta = ""
            for part in parts:
                if isinstance(part, tuple):
                    meta += part[0].decode(errors="ignore")
                    raw += part[1]
            msg = email.message_from_bytes(raw)
            sender = decode(msg.get("From"))
            subject = decode(msg.get("Subject"))
            dt = None
            try:
                dt = parsedate_to_datetime(msg.get("Date"))
                if dt and dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
            except Exception:
                pass
            size_match = re.search(r"RFC822\.SIZE\s+(\d+)", meta)
            size = int(size_match.group(1)) if size_match else 0
            newsletter = any(msg.get(h) for h in ("List-Unsubscribe", "List-Id", "Precedence"))
            attachment = "attachment" in (msg.get("Content-Disposition", "").lower())
            if cutoff and (not dt or dt >= cutoff):
                continue
            if rules.get("larger_mb") and size < int(rules["larger_mb"]) * 1024 * 1024:
                continue
            if rules.get("newsletter_only") and not newsletter:
                continue
            if rules.get("has_attachment") and not attachment:
                continue
            if rules.get("sender") and rules["sender"].lower() not in sender.lower():
                continue
            if rules.get("subject") and rules["subject"].lower() not in subject.lower():
                continue
            output.append(MailItem(
                provider="OVH", account_id=self.address, message_id=uid, date=dt,
                sender=sender, subject=subject, size_bytes=size,
                unread="\\Seen" not in meta, newsletter=newsletter,
                has_attachment=attachment
            ))
            if progress:
                progress(i, len(ids), len(output))
        return output

    def _find_folder(self, names):
        status, boxes = self.client.list()
        lines = [b.decode(errors="ignore") for b in boxes] if status == "OK" else []
        for name in names:
            for line in lines:
                if name.lower() in line.lower():
                    match = re.search(r'(?:"([^"]+)"|(\S+))$', line)
                    if match:
                        return match.group(1) or match.group(2)
        return None

    def archive(self, message_ids):
        self.client.select("INBOX")
        folder = self._find_folder(["Archive", "Archives"])
        if not folder:
            raise RuntimeError("Dossier Archives introuvable sur cette boîte OVH.")
        for uid in message_ids:
            self.client.uid("copy", uid, f'"{folder}"')
            self.client.uid("store", uid, "+FLAGS", r"(\Deleted)")
        self.client.expunge()

    def trash(self, message_ids):
        self.client.select("INBOX")
        folder = self._find_folder(["Trash", "Corbeille", "Deleted"])
        for uid in message_ids:
            if folder:
                self.client.uid("copy", uid, f'"{folder}"')
            self.client.uid("store", uid, "+FLAGS", r"(\Deleted)")
        self.client.expunge()
