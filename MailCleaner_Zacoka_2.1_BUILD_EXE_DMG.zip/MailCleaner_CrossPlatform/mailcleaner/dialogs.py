
import shutil
from pathlib import Path
import keyring
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QFileDialog,
    QMessageBox, QHBoxLayout, QLabel
)
from .config import GOOGLE_CREDENTIALS, load_config, save_config, ensure_dirs
from .providers.ovh import SERVICE

class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Paramètres OAuth")
        self.resize(620, 250)
        self.config = load_config()
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.google_path = QLineEdit(str(GOOGLE_CREDENTIALS) if GOOGLE_CREDENTIALS.exists() else "")
        google_row = QHBoxLayout()
        google_row.addWidget(self.google_path)
        browse = QPushButton("Choisir le JSON…")
        browse.clicked.connect(self.choose_google)
        google_row.addWidget(browse)
        form.addRow("Fichier OAuth Google :", google_row)
        self.ms_client = QLineEdit(self.config.get("microsoft_client_id", ""))
        self.ms_client.setPlaceholderText("ID client de l'application Microsoft Entra")
        form.addRow("Client ID Microsoft :", self.ms_client)
        layout.addLayout(form)
        note = QLabel(
            "Ces identifiants servent uniquement à identifier MailCleaner auprès de Google et Microsoft. "
            "Les mots de passe Gmail et Outlook ne sont jamais demandés."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        buttons = QHBoxLayout()
        buttons.addStretch()
        save = QPushButton("Enregistrer")
        save.clicked.connect(self.save)
        buttons.addWidget(save)
        layout.addLayout(buttons)

    def choose_google(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choisir credentials.json", "", "JSON (*.json)")
        if path:
            self.google_path.setText(path)

    def save(self):
        ensure_dirs()
        source = self.google_path.text().strip()
        if source and Path(source).resolve() != GOOGLE_CREDENTIALS.resolve():
            try:
                shutil.copy2(source, GOOGLE_CREDENTIALS)
            except Exception as exc:
                QMessageBox.critical(self, "Erreur", str(exc))
                return
        self.config["microsoft_client_id"] = self.ms_client.text().strip()
        save_config(self.config)
        self.accept()

class OvhDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ajouter une boîte OVH")
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.address = QLineEdit()
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.host = QLineEdit("ssl0.ovh.net")
        form.addRow("Adresse e-mail :", self.address)
        form.addRow("Mot de passe :", self.password)
        form.addRow("Serveur IMAP :", self.host)
        layout.addLayout(form)
        button = QPushButton("Ajouter")
        button.clicked.connect(self.accept)
        layout.addWidget(button)

    def values(self):
        return self.address.text().strip(), self.password.text(), self.host.text().strip()
