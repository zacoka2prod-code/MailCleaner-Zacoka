
import csv
from collections import defaultdict
from pathlib import Path

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QPushButton,
    QComboBox, QSpinBox, QCheckBox, QLineEdit, QTableWidget, QTableWidgetItem,
    QHeaderView, QLabel, QMessageBox, QFileDialog, QProgressBar, QAbstractItemView,
    QTabWidget, QGroupBox
)

from .config import load_config, save_config, GOOGLE_CREDENTIALS
from .dialogs import SettingsDialog, OvhDialog
from .providers.gmail import GmailProvider
from .providers.microsoft import MicrosoftProvider
from .providers.ovh import OvhProvider
from .worker import Worker

CHECKED = Qt.CheckState.Checked
UNCHECKED = Qt.CheckState.Unchecked

class MailCleanerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MailCleaner Zacoka 2")
        self.resize(1350, 800)
        self.config = load_config()
        self.providers = {}
        self.items = []
        self.thread_pool = QThreadPool.globalInstance()
        self.active_workers = []
        self._build_ui()
        self.refresh_accounts()

    def _build_ui(self):
        settings_action = QAction("Paramètres OAuth", self)
        settings_action.triggered.connect(self.open_settings)
        self.menuBar().addMenu("Configuration").addAction(settings_action)

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        title = QLabel("MailCleaner Zacoka")
        title.setStyleSheet("font-size: 24px; font-weight: 700;")
        subtitle = QLabel("Sélectionnez visuellement les messages à archiver ou à placer dans la corbeille.")
        subtitle.setStyleSheet("color: #666;")
        root.addWidget(title)
        root.addWidget(subtitle)

        controls = QHBoxLayout()
        root.addLayout(controls)

        account_box = QGroupBox("1. Compte")
        account_layout = QVBoxLayout(account_box)
        self.account_combo = QComboBox()
        account_layout.addWidget(self.account_combo)
        account_buttons = QHBoxLayout()
        self.google_button = QPushButton("Connexion Google")
        self.microsoft_button = QPushButton("Connexion Microsoft")
        self.ovh_button = QPushButton("Ajouter OVH")
        self.google_button.clicked.connect(lambda: self.connect_provider("Gmail"))
        self.microsoft_button.clicked.connect(lambda: self.connect_provider("Microsoft"))
        self.ovh_button.clicked.connect(self.add_ovh)
        account_buttons.addWidget(self.google_button)
        account_buttons.addWidget(self.microsoft_button)
        account_buttons.addWidget(self.ovh_button)
        account_layout.addLayout(account_buttons)
        controls.addWidget(account_box, 2)

        rules_box = QGroupBox("2. Filtres")
        rules = QFormLayout(rules_box)
        self.age_enabled = QCheckBox("Activer")
        self.age = QSpinBox()
        self.age.setRange(1, 5000)
        self.age.setValue(365)
        age_row = QHBoxLayout()
        age_row.addWidget(self.age_enabled)
        age_row.addWidget(self.age)
        age_row.addWidget(QLabel("jours"))
        rules.addRow("Plus vieux que :", age_row)

        self.size_enabled = QCheckBox("Activer")
        self.size = QSpinBox()
        self.size.setRange(1, 5000)
        self.size.setValue(10)
        size_row = QHBoxLayout()
        size_row.addWidget(self.size_enabled)
        size_row.addWidget(self.size)
        size_row.addWidget(QLabel("Mo"))
        rules.addRow("Plus gros que :", size_row)

        self.newsletter = QCheckBox("Uniquement les newsletters")
        self.unread = QCheckBox("Uniquement les non lus")
        self.attachments = QCheckBox("Avec pièces jointes")
        flags = QHBoxLayout()
        flags.addWidget(self.newsletter)
        flags.addWidget(self.unread)
        flags.addWidget(self.attachments)
        rules.addRow(flags)
        self.sender = QLineEdit()
        self.subject = QLineEdit()
        rules.addRow("Expéditeur contient :", self.sender)
        rules.addRow("Objet contient :", self.subject)
        controls.addWidget(rules_box, 4)

        scan_box = QGroupBox("3. Analyse")
        scan_layout = QVBoxLayout(scan_box)
        self.limit = QSpinBox()
        self.limit.setRange(50, 2000)
        self.limit.setSingleStep(50)
        self.limit.setValue(500)
        scan_layout.addWidget(QLabel("Messages maximum"))
        scan_layout.addWidget(self.limit)
        self.scan_button = QPushButton("Analyser")
        self.scan_button.setMinimumHeight(42)
        self.scan_button.clicked.connect(self.scan)
        scan_layout.addWidget(self.scan_button)
        controls.addWidget(scan_box, 1)

        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels([
            "✓", "Compte", "Date", "Expéditeur", "Objet", "Taille",
            "Non lu", "Newsletter", "Pièce jointe"
        ])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        for col in range(5, 9):
            self.table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
        root.addWidget(self.table, 1)

        actions = QHBoxLayout()
        self.summary = QLabel("Aucun message analysé.")
        actions.addWidget(self.summary)
        actions.addStretch()
        select_all = QPushButton("Tout cocher")
        clear_all = QPushButton("Tout décocher")
        export = QPushButton("Exporter CSV")
        archive = QPushButton("Archiver la sélection")
        trash = QPushButton("Mettre à la corbeille")
        select_all.clicked.connect(lambda: self.set_all_checks(True))
        clear_all.clicked.connect(lambda: self.set_all_checks(False))
        export.clicked.connect(self.export_csv)
        archive.clicked.connect(lambda: self.perform_action("archive"))
        trash.clicked.connect(lambda: self.perform_action("trash"))
        for button in (select_all, clear_all, export, archive, trash):
            actions.addWidget(button)
        root.addLayout(actions)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        root.addWidget(self.progress)

    def open_settings(self):
        dialog = SettingsDialog(self)
        if dialog.exec():
            self.config = load_config()
            self.refresh_accounts()

    def refresh_accounts(self):
        current = self.account_combo.currentText()
        self.account_combo.clear()
        for key, provider in self.providers.items():
            self.account_combo.addItem(f"{provider.account_label()} ({key})", key)
        for entry in self.config.get("ovh_accounts", []):
            key = f"OVH:{entry['address']}"
            if key not in self.providers:
                self.providers[key] = OvhProvider(entry["address"], entry.get("host", "ssl0.ovh.net"))
                self.account_combo.addItem(f"{entry['address']} (OVH)", key)

    def connect_provider(self, kind):
        self.config = load_config()

        if kind == "Gmail":
            if not GOOGLE_CREDENTIALS.exists():
                answer = QMessageBox.question(
                    self,
                    "Configuration Google nécessaire",
                    "Importez d'abord le fichier credentials.json Google.\n\n"
                    "Ouvrir les paramètres maintenant ?"
                )
                if answer == QMessageBox.StandardButton.Yes:
                    self.open_settings()
                return
            provider = GmailProvider()
            key = "Gmail"
        else:
            client_id = self.config.get("microsoft_client_id", "").strip()
            if not client_id:
                answer = QMessageBox.question(
                    self,
                    "Configuration Microsoft nécessaire",
                    "Ajoutez d'abord l'identifiant client Microsoft Entra.\n\n"
                    "Ouvrir les paramètres maintenant ?"
                )
                if answer == QMessageBox.StandardButton.Yes:
                    self.open_settings()
                return
            provider = MicrosoftProvider(client_id)
            key = "Microsoft"

        QMessageBox.information(
            self,
            "Connexion",
            f"Votre navigateur va s'ouvrir pour la connexion {kind}."
        )
        self.run_task(provider.connect, on_result=lambda _: self._connected(key, provider))

    def _connected(self, key, provider):
        self.providers[key] = provider
        self.refresh_accounts()
        index = self.account_combo.findData(key)
        if index >= 0:
            self.account_combo.setCurrentIndex(index)
        QMessageBox.information(self, "Connexion réussie", f"Compte connecté : {provider.account_label()}")

    def add_ovh(self):
        dialog = OvhDialog(self)
        if not dialog.exec():
            return
        address, password, host = dialog.values()
        if not address or not password:
            QMessageBox.warning(self, "OVH", "Adresse et mot de passe obligatoires.")
            return
        provider = OvhProvider(address, host)
        provider.set_password(password)
        entries = self.config.setdefault("ovh_accounts", [])
        entries = [e for e in entries if e.get("address") != address]
        entries.append({"address": address, "host": host})
        self.config["ovh_accounts"] = entries
        save_config(self.config)
        self.providers[f"OVH:{address}"] = provider
        self.refresh_accounts()
        self.connect_provider_key(f"OVH:{address}")

    def connect_provider_key(self, key):
        provider = self.providers[key]
        self.run_task(provider.connect, on_result=lambda _: QMessageBox.information(self, "Connexion", "Connexion OVH réussie."))

    def selected_provider(self):
        key = self.account_combo.currentData()
        return self.providers.get(key), key

    def rules(self):
        return {
            "older_days": self.age.value() if self.age_enabled.isChecked() else 0,
            "larger_mb": self.size.value() if self.size_enabled.isChecked() else 0,
            "newsletter_only": self.newsletter.isChecked(),
            "unread_only": self.unread.isChecked(),
            "has_attachment": self.attachments.isChecked(),
            "sender": self.sender.text().strip(),
            "subject": self.subject.text().strip(),
            "limit": self.limit.value(),
        }

    def scan(self):
        provider, key = self.selected_provider()
        if not provider:
            QMessageBox.warning(self, "Compte", "Connectez d'abord un compte Google, Microsoft ou OVH.")
            return
        self.items = []
        self.table.setRowCount(0)
        self.run_task(
            provider.scan, self.rules(),
            on_result=self.display_items,
            with_progress=True
        )

    def display_items(self, items):
        self.items = items
        self.table.setRowCount(len(items))
        for row, item in enumerate(items):
            check = QTableWidgetItem()
            check.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            check.setCheckState(CHECKED)
            self.table.setItem(row, 0, check)
            values = [
                item.account_id,
                item.date.astimezone().strftime("%d/%m/%Y %H:%M") if item.date else "",
                item.sender, item.subject, item.size_text,
                "Oui" if item.unread else "Non",
                "Oui" if item.newsletter else "Non",
                "Oui" if item.has_attachment else "Non",
            ]
            for col, value in enumerate(values, 1):
                cell = QTableWidgetItem(str(value))
                cell.setData(Qt.ItemDataRole.UserRole, item)
                self.table.setItem(row, col, cell)
        total = sum(i.size_bytes for i in items)
        self.summary.setText(f"{len(items)} message(s) — environ {self.format_size(total)}")

    def selected_items(self):
        selected = []
        for row in range(self.table.rowCount()):
            if self.table.item(row, 0).checkState() == CHECKED:
                selected.append(self.items[row])
        return selected

    def set_all_checks(self, checked):
        for row in range(self.table.rowCount()):
            self.table.item(row, 0).setCheckState(CHECKED if checked else UNCHECKED)

    def perform_action(self, action):
        provider, key = self.selected_provider()
        selected = self.selected_items()
        if not provider or not selected:
            QMessageBox.warning(self, "Sélection", "Aucun message coché.")
            return
        wording = "archiver" if action == "archive" else "déplacer vers la corbeille"
        answer = QMessageBox.question(
            self, "Confirmation",
            f"Voulez-vous {wording} {len(selected)} message(s) ?\n\n"
            "Aucune suppression définitive ne sera effectuée."
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        ids = [item.message_id for item in selected]
        function = provider.archive if action == "archive" else provider.trash
        self.run_task(function, ids, on_result=lambda _: self.after_action(selected))

    def after_action(self, selected):
        self.items = [item for item in self.items if item not in selected]
        self.display_items(self.items)
        QMessageBox.information(self, "Terminé", f"{len(selected)} message(s) traité(s).")

    def export_csv(self):
        if not self.items:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Exporter", "mailcleaner.csv", "CSV (*.csv)")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle, delimiter=";")
            writer.writerow(["Sélectionné", "Compte", "Date", "Expéditeur", "Objet", "Taille", "Non lu", "Newsletter", "Pièce jointe"])
            for row, item in enumerate(self.items):
                writer.writerow([
                    self.table.item(row, 0).checkState() == CHECKED,
                    item.account_id, item.date.isoformat() if item.date else "",
                    item.sender, item.subject, item.size_bytes,
                    item.unread, item.newsletter, item.has_attachment
                ])
        QMessageBox.information(self, "Export", "Le fichier CSV a été créé.")

    def run_task(self, function, *args, on_result=None, with_progress=False):
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.scan_button.setEnabled(False)
        worker = Worker(function, *args)
        self.active_workers.append(worker)
        if on_result:
            worker.signals.result.connect(on_result)
        worker.signals.error.connect(lambda text: QMessageBox.critical(self, "Erreur", text))
        if with_progress:
            worker.signals.progress.connect(self.update_progress)
        worker.signals.finished.connect(self.task_finished)
        worker.signals.finished.connect(lambda w=worker: self.release_worker(w))
        self.thread_pool.start(worker)

    def release_worker(self, worker):
        if worker in self.active_workers:
            self.active_workers.remove(worker)

    def update_progress(self, current, total, matched):
        self.summary.setText(f"Analyse : {current}/{total} — {matched} résultat(s)")

    def task_finished(self):
        self.progress.setVisible(False)
        self.scan_button.setEnabled(True)

    @staticmethod
    def format_size(size):
        value = float(size)
        for unit in ["o", "Ko", "Mo", "Go"]:
            if value < 1024 or unit == "Go":
                return f"{value:.1f} {unit}"
            value /= 1024
